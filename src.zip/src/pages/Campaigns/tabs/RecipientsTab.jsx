// 📁 src/pages/Campaigns/tabs/RecipientsTab.jsx
import React from "react";

function RecipientsTab({ formData, setFormData }) {
  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Recipients</h3>
      <p className="text-gray-600">Recipient selection feature coming soon.</p>
    </div>
  );
}

export default RecipientsTab;
